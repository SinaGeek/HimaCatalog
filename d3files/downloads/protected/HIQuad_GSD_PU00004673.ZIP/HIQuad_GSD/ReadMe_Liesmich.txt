Beim Entpacken werden sie die folgenden GSD-Dateien in Ordnern vorfinden:
hima00ea.gsd: F8626 bis Betriebssystemversion V 1.14
hiq100ea.gsd: F8626 ab Betriebssystemversion  V 1.15
hiq200ea.gsd: F8628 und F8628X

When you unpack the ZIP-File you will find the following GSD-files in folders:
hima00ea.gsd: F8626 until operating system V 1.14
hiq100ea.gsd: F8626 from  operating system V 1.15
hiq200ea.gsd: F8628 and F8628X