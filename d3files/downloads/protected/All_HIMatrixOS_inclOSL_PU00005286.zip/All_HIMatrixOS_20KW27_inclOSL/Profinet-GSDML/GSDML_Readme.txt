Ich empfehle die Version GSDML-V2.2-Hima-xxxxxx-20130402 einzusetzen.
Bitte die Hinweise im Freigabeblatt der COM BS-Version beachten.

Die Version GSDML-V2.2-Hima-xxxxxx-20101221 wird nur dann ben�tigt, 
wenn im Projekt F-Module > 8 Byte ben�tigt werden oder im Freigabeblatt des
COM-Betriebsystems diese Version angegeben ist.
Die Version GSDML-V2.2-Hima-xxxxxx-20101221 l�sst sich in Siemens Step 7 ab 
ca. 2013 bedingt durch F-Module > 8 Byte nicht importieren.


08.03.2016 Gerd Schirdewahn/EDS
